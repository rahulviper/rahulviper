package healthcare;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/registration")
public class registration extends HttpServlet {

	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		String e=req.getParameter("t5");
		String but=req.getParameter("b1");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
			 PreparedStatement ps=con.prepareStatement("insert into registration values(?,?,?,?,?)");
			ps.setString(1,a);
			ps.setString(2,b);
			ps.setString(3,c);
			ps.setString(4,d);
			ps.setString(5,e);
			ps.execute();
			pw.print("Data Stored");
			res.sendRedirect("login.html");
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}

}